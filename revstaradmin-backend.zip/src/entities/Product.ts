export interface Product {
  name: string;
  amount: number;
  price: number;
  description: string;
  image: string;
}