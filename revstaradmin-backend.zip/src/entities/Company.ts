export interface Company {
  nit: string,
  name: string,
  address: string
  phone: string,
}